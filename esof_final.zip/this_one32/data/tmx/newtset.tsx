<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="newtset" tilewidth="16" tileheight="16" tilecount="3160" columns="79">
 <image source="../graphics/tilesets/newtset.png" width="1271" height="644"/>
</tileset>
