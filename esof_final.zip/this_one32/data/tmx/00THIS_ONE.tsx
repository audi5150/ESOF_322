<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="00THIS_ONE" tilewidth="32" tileheight="32" tilecount="924" columns="33">
 <image source="../../graphics/tilesets/00THIS_ONE.png" width="1056" height="896"/>
</tileset>
