<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="newset" tilewidth="32" tileheight="32" tilecount="1224" columns="72">
 <image source="../graphics/tilesets/newset.png" trans="a2d8ff" width="2308" height="575"/>
</tileset>
