<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="newset16" tilewidth="16" tileheight="16" spacing="1" tilecount="1072" columns="67">
 <image source="../graphics/tilesets/newset16.png" trans="a2d8ff" width="1152" height="287"/>
</tileset>
