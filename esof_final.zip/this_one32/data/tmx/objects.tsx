<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="jump" tilewidth="96" tileheight="93" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="96" height="93" source="../../graphics/clouds/cloud2.png"/>
 </tile>
</tileset>
