<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="0newest" tilewidth="16" tileheight="16" tilecount="1014" columns="26">
 <image source="../graphics/tilesets/0newest.png" width="426" height="629"/>
</tileset>
