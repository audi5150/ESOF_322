<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="newtset" tilewidth="32" tileheight="32" tilecount="780" columns="39">
 <image source="../graphics/tilesets/newtset.png" width="1271" height="644"/>
</tileset>
