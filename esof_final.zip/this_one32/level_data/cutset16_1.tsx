<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="cutset16_1" tilewidth="32" tileheight="32" tilecount="240" columns="16">
 <image source="../../16/graphics/tilesets/cutset16_1.png" trans="aaffff" width="540" height="495"/>
</tileset>
