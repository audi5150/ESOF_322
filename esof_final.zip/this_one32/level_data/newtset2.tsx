<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="newtset" tilewidth="32" tileheight="32" tilecount="800" columns="40">
 <image source="../graphics/tilesets/newtset.png" trans="55ffff" width="1283" height="654"/>
</tileset>
