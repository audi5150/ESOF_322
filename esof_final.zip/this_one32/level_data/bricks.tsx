<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bricks" tilewidth="32" tileheight="32" tilecount="112" columns="14">
 <image source="../graphics/tilesets/bricks.png" width="448" height="256"/>
</tileset>
