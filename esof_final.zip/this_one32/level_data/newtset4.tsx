<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="newtset4" tilewidth="32" tileheight="32" tilecount="81" columns="9">
 <image source="../graphics/tilesets/newtset4.png" width="289" height="289"/>
</tileset>
