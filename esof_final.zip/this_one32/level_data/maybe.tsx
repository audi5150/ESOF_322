<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="maybe" tilewidth="32" tileheight="32" tilecount="288" columns="18">
 <image source="../../16/graphics/tilesets/maybe.png" width="576" height="528"/>
</tileset>
