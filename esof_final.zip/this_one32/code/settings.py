vertical_tile_num = 20
tile_size = 32

sc_hei = vertical_tile_num * tile_size
sc_wid = 900

