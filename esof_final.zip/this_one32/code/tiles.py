import pygame as pg
from support import import_folder

class Tile(pg.sprite.Sprite):
    def __init__(self,size,x,y):
        super().__init__()
        self.image = pg.Surface((size,size))
        #self.image.fill('Green')
        self.rect = self.image.get_rect(topleft = (x,y))
    def update(self,shift):
        self.rect.x += shift
        
class StaticTile(Tile):
    def __init__(self,size,x,y,surface):
        super().__init__(size,x,y)
        self.image = surface

class AnimatedTile(Tile):
    def __init__(self,size,x,y,path):
        super().__init__(size,x,y)
        self.frames = import_folder(path)
        self.frame_index = 0
        self.image = self.frames[self.frame_index]
    def animate(self):
        self.frame_index += 0.15
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]
    def update(self,shift):
        
        self.rect.x += shift
        self.animate()


class Coin(AnimatedTile):
    def __init__(self,size,x,y,path):
        super().__init__(size,x,y,path)
        center_x = x + int(size/2)
        center_y = y + int(size/2)
        self.rect = self.image.get_rect(center=(center_x,center_y))

##class Platform(AnimatedTile):
##    def __init__(self,size,x,y,path):
##        super().__init__(size,x,y,path)
##        self.rect = self.image.get_rect(center = (x,y))
##        self.speed = 3
##    def move(self):
##        self.rect.x += self.speed
##    def update(self):
##        self.rect.x += shift
##        self.move()
##        self.animate()

    

       

        
        
        
