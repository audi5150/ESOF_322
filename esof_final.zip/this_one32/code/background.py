import pygame as pg
from settings import sc_wid,tile_size,vertical_tile_num
from support import import_folder
from random import choice,randint
from tiles import StaticTile


class Sky:
    def __init__(self,style = 'level'):
        self.lvl = pg.image.load('../graphics/sky/bg/bg.png').convert()
      
        self.oworld = pg.image.load('../graphics/overworld_graphics/overworld_map.png').convert()
        self.lvl1 = pg.image.load('../graphics/sky/bg/bg5.png').convert()
        self.lvl_2 = pg.image.load('../graphics/sky/bg/bg1.png').convert()
        self.style = style


    def draw(self,surface):
        if self.style == 'overworld':
            self.image = self.oworld
        if self.style == 'level':
            self.image = self.lvl
        surface.blit(self.image,(0,0))

