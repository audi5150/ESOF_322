
level_0 = {
    'terrain':'../levels/0/level_0_terrain.csv',
    'coins':'../levels/0/level_0_coins.csv',
    'constraints':'../levels/0/level_0_constraints.csv',
    'player':'../levels/0/level_0_player.csv',
    'enemies':'../levels/0/level_0_enemies.csv',
    'green':'../levels/0/level_0_green.csv',
    'platform':'../levels/0/level_0/level_0.platform.csv',
    'node_pos':(125,225),
    'unlock':1,
    'node_graphics':'../graphics/overworld_graphics/0' }
level_1 = {
    'terrain':'../levels/1/level_1_terrain.csv',
    'coins':'../levels/1/level_1_coins.csv',
    'constraints':'../levels/1/level_1_constraints.csv',
    'player':'../levels/1/level_1_player.csv',
    'enemies':'../levels/1/level_1_enemies.csv',
    'green':'../levels/1/level_1_green.csv',

    'node_pos':(125,400),
    'unlock':2,
    'node_graphics':'../graphics/overworld_graphics/1' }
level_2 = {
    'terrain':'../levels/2/level_2_terrain.csv',
    'coins':'../levels/2/level_2_coins.csv',
    'constraints':'../levels/2/level_2_constraints.csv',
    'player':'../levels/2/level_2_player.csv',
    'enemies':'../levels/2/level_2_enemies.csv',
    'green':'../levels/2/level_2_green.csv',

    'node_pos':(225,525),
    'unlock':3,
    'node_graphics':'../graphics/overworld_graphics/2' }
level_3 = {
    'terrain':'../levels/3/level_3_terrain.csv',
    'coins':'../levels/3/level_3_coins.csv',
    'constraints':'../levels/3/level_3_constraints.csv',
    'player':'../levels/3/level_3_player.csv',
    'enemies':'../levels/3/level_3_enemies.csv',
    'green':'../levels/3/level_3_green.csv',
    'node_pos':(225,400),
    'unlock':4,
    'node_graphics':'../graphics/overworld_graphics/3' }

level_4= {
    'terrain':'../levels/4/level_4_terrain.csv',
    'coins':'../levels/4/level_4_coins.csv',
    'constraints':'../levels/4/level_4_constraints.csv',
    'player':'../levels/4/level_4_player.csv',
    'enemies':'../levels/4/level_4_enemies.csv',
    'green':'../levels/4/level_4_green.csv',
    'node_pos':(225,250),
    'unlock':5,
    'node_graphics':'../graphics/overworld_graphics/4' }
level_5= {
    'terrain':'../levels/5/level_5_terrain.csv',
    'coins':'../levels/5/level_5_coins.csv',
    'constraints':'../levels/5/level_5_constraints.csv',
    'player':'../levels/5/level_5_player.csv',
    'enemies':'../levels/5/level_5_enemies.csv',
    'green':'../levels/5/level_5_green.csv',
    'node_pos':(350,250),
    'unlock':6,
    'node_graphics':'../graphics/overworld_graphics/5' }
##level_6={
##    'terrain':'../levels/5/level_5_terrain.csv',
##    'coins':'../levels/5/level_5_coins.csv',
##    'constraints':'../levels/5/level_5_constraints.csv',
##    'player':'../levels/5/level_5_player.csv',
##    'enemies':'../levels/5/level_5_enemies.csv',
##    'green':'../levels/5/level_5_green.csv',
##    'node_pos':(350,250),
##    'unlock':6,
##    'node_graphics':'../graphics/overworld_graphics/5' }
level_6 = {
    'terrain':'../levels/6/level_6_terrain.csv',
    'coins':'../levels/6/level_6_coins.csv',
    'constraints':'../levels/6/level_6_constraints.csv',
    'player':'../levels/6/level_6_player.csv',
    'enemies':'../levels/6/level_6_enemies.csv',
    'green':'../levels/6/level_6_green.csv',
    'node_pos':(350,400),
    'unlock':6,
    'node_graphics':'../graphics/overworld_graphics/6' }

levels={
    0:level_0,
    1:level_1,
    2:level_2,
    3:level_3,
    4:level_4,
    5:level_5,
    6:level_6



    }
